const config = {}
config.SERVER = 'cluster0.ioglstf.mongodb.net'
config.USERNAME = 'admin-ganga'
config.PASSOWRD = 'Sandhu96003'
config.DATABASE = 'blog'
module.exports = config